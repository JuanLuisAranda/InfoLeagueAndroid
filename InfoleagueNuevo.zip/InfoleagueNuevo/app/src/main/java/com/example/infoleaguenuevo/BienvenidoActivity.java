package com.example.infoleaguenuevo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;

public class BienvenidoActivity extends AppCompatActivity {

    ArrayList<Equipos> listaequipos;
    RecyclerView recyclerequipos;

    public static final String user="names";
    TextView txtUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bienvenido);


        txtUser = (TextView) findViewById(R.id.textUser);
        String user = getIntent().getStringExtra("names");
        txtUser.setText("¡Bienvenido " + user + "!");

        listaequipos = new ArrayList<>();
        recyclerequipos = findViewById(R.id.recyclerEquipo);
        recyclerequipos.setLayoutManager(new LinearLayoutManager(this));
        llenarequipos();
        Adaptadorequipos adapter = new Adaptadorequipos(listaequipos);
        recyclerequipos.setAdapter(adapter);

    }

    private void llenarequipos(){
        listaequipos.add(new Equipos("Real Madrid", R.drawable.ico_rmcf));
        listaequipos.add(new Equipos("FC Barcelona", R.drawable.ico_barcelona));
        listaequipos.add(new Equipos("Atlético de Madrid", R.drawable.atm));
        listaequipos.add(new Equipos("Real Sociedad", R.drawable.rso));
        listaequipos.add(new Equipos("Valencia CF", R.drawable.vcf));
        listaequipos.add(new Equipos("Alavvés", R.drawable.ala));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater() ;
        inflater.inflate(R.menu.menu_principal, menu) ;
        //
        return true ;
    }

    /**
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.desconectar :

                Intent irAPrincipio = new Intent(BienvenidoActivity.this, MainActivity.class);
                startActivity(irAPrincipio);

                return true ;
        }

        return super.onOptionsItemSelected(item);
    }

}
